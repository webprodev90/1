<script>
  import Navbar from "../components/Navbar.svelte";
  import Footer from "../components/Footer.svelte";

  export let status;
  export let error;

  const dev = process.env.NODE_ENV === "development";
</script>

<style>
</style>

<svelte:head>
  <title>{status}</title>
</svelte:head>

<!--<Navbar/>-->

<section class="section">
  <div class="container">

    <h1>{status}</h1>

    <p>{error.message}</p>

    {#if dev && error.stack}
      <pre>{error.stack}</pre>
    {/if}

  </div>
</section>

<!--<Footer/>-->
