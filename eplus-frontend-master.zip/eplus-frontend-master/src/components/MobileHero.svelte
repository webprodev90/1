<script>
</script>

<style>
</style>


<section class="hero is-large is-primary is-hidden-desktop">
  <div class="hero-head">
    <slot name="head"/>
  </div>
  <div class="hero-body">
    <slot name="body"/>
  </div>
  <div class="hero-foot">
    <slot name="footer"/>
  </div>
</section>
